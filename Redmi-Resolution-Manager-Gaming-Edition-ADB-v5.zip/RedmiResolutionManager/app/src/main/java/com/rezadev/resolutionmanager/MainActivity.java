package com.rezadev.resolutionmanager;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.SeekBar;
import android.widget.ArrayAdapter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import android.provider.Settings;
import android.net.Uri;
import android.content.Intent;
import android.content.SharedPreferences;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class MainActivity extends Activity {
    private static final int REQUEST_CODE = 4107;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private TextView statusText, currentText, logText;
    private Button connectButton;
    private static final String COD_PACKAGE = "com.activision.callofduty.shooter";
    private static final String COD_GARENA_PACKAGE = "com.garena.game.codm";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        updateConnectionState();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(28));
        root.setBackgroundColor(Color.rgb(9, 11, 18));
        scroll.addView(root);

        TextView brand = text("RR  /  REDMI TOOLS", 12, 0xFF9A8BFF, true);
        brand.setLetterSpacing(0.12f);
        root.addView(brand);
        TextView title = text("Resolution\nManager", 32, Color.WHITE, true);
        title.setPadding(0, dp(10), 0, dp(4));
        root.addView(title);
        root.addView(text("کنترل رزولوشن و تراکم نمایشگر", 14, 0xFF9AA3B5, false));

        LinearLayout statusCard = card();
        statusCard.setPadding(dp(16), dp(14), dp(16), dp(14));
        statusText = text("در حال بررسی سرویس...", 14, 0xFFFFC857, true);
        statusCard.addView(statusText);
        connectButton = button("اتصال ADB داخلی / جفت‌سازی", 0xFF292443);
        connectButton.setOnClickListener(v -> connectOrRequest());
        statusCard.addView(connectButton, matchWrap());
        root.addView(statusCard, paramsTop(0, 20));

        TextView choose = text("انتخاب پروفایل", 18, Color.WHITE, true);
        choose.setPadding(0, dp(24), 0, dp(12));
        root.addView(choose);
        root.addView(profile("LOW  •  360p-like", "270 × 600", "140 DPI", "wm size 270x600 && wm density 140"), paramsTop(0, 10));
        root.addView(profile("BALANCED  •  480p-like", "360 × 800", "180 DPI", "wm size 360x800 && wm density 180"), paramsTop(0, 10));
        root.addView(profile("HIGH  •  480-width", "480 × 1067", "220 DPI", "wm size 480x1067 && wm density 220"), paramsTop(0, 10));

        Button reset = button("↺   بازگردانی تنظیمات کارخانه", 0xFF3A2028);
        reset.setTextColor(0xFFFFA6B2);
        reset.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("بازگردانی تنظیمات؟")
                .setMessage("رزولوشن و تراکم نمایشگر به مقادیر پیش‌فرض سیستم برمی‌گردند.")
                .setNegativeButton("لغو", null)
                .setPositiveButton("بازگردانی", (d, w) -> runShell("wm size reset && wm density reset", "تنظیمات پیش‌فرض بازیابی شد"))
                .show());
        root.addView(reset, paramsTop(0, 22));

        TextView currentTitle = text("وضعیت نمایشگر", 17, Color.WHITE, true);
        currentTitle.setPadding(0, dp(24), 0, dp(10));
        root.addView(currentTitle);
        LinearLayout info = card();
        info.setPadding(dp(16), dp(14), dp(16), dp(14));
        currentText = text("برای خواندن وضعیت، سرویس را متصل کن.", 13, 0xFFB9C1D1, false);
        info.addView(currentText);
        Button refresh = button("بررسی دوباره", 0xFF202635);
        refresh.setOnClickListener(v -> refreshCurrent());
        info.addView(refresh, paramsTop(0, 10));
        root.addView(info);

        TextView gamingTitle = text("Gaming Overlay  /  نشانگر وسط صفحه", 18, Color.WHITE, true);
        gamingTitle.setPadding(0, dp(26), 0, dp(12));
        root.addView(gamingTitle);
        LinearLayout overlayCard = card();
        overlayCard.setPadding(dp(16), dp(14), dp(16), dp(14));
        root.addView(overlayCard, paramsTop(0, 8));
        overlayCard.addView(text("نشانگر شناور با شکل، رنگ، اندازه و شفافیت قابل تنظیم", 13, 0xFFB9C1D1, false));
        Button overlayToggle = button("روشن / خاموش کردن نشانگر", 0xFF24483D);
        overlayToggle.setOnClickListener(v -> toggleCrosshair());
        overlayCard.addView(overlayToggle, paramsTop(0, 12));
        Button shapeButton = button("انتخاب شکل نشانگر", 0xFF252D3D);
        shapeButton.setOnClickListener(v -> chooseCrosshairShape());
        overlayCard.addView(shapeButton, paramsTop(0, 8));
        Button colorButton = button("انتخاب رنگ نشانگر", 0xFF252D3D);
        colorButton.setOnClickListener(v -> chooseCrosshairColor());
        overlayCard.addView(colorButton, paramsTop(0, 8));
        overlayCard.addView(text("اندازه نشانگر: ۵۰٪ تا ۲۰۰٪", 12, 0xFF9AA3B5, false), paramsTop(0, 12));
        SeekBar sizeSeek = new SeekBar(this); sizeSeek.setMax(150); sizeSeek.setProgress(50);
        sizeSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int value, boolean user) { saveOverlay("size", value + 50); updateOverlayIfRunning(); }
            public void onStartTrackingTouch(SeekBar b) {} public void onStopTrackingTouch(SeekBar b) {}
        });
        overlayCard.addView(sizeSeek, matchWrap());
        overlayCard.addView(text("شفافیت نشانگر: ۰٪ تا ۱۰۰٪", 12, 0xFF9AA3B5, false), paramsTop(0, 8));
        SeekBar opacitySeek = new SeekBar(this); opacitySeek.setMax(100); opacitySeek.setProgress(100);
        opacitySeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int value, boolean user) { saveOverlay("opacity", value); updateOverlayIfRunning(); }
            public void onStartTrackingTouch(SeekBar b) {} public void onStopTrackingTouch(SeekBar b) {}
        });
        overlayCard.addView(opacitySeek, matchWrap());
        overlayCard.addView(text("کنترل FPS و Touch Mapping از پنل شناور Gaming در بخش پایین در دسترس است.", 12, 0xFFFFC857, false), paramsTop(0, 14));

        TextView appsTitle = text("مدیریت برنامه‌ها و پاک‌سازی RAM", 18, Color.WHITE, true);
        appsTitle.setPadding(0, dp(26), 0, dp(12));
        root.addView(appsTitle);
        LinearLayout appsCard = card();
        appsCard.setPadding(dp(16), dp(14), dp(16), dp(14));
        root.addView(appsCard);
        appsCard.addView(text("برنامه‌های قابل اجرا را به فهرست سیاه یا سفید اضافه کن. COD Mobile و خود این برنامه همیشه از پاک‌سازی مستثنا هستند.", 13, 0xFFB9C1D1, false));
        Button manageApps = button("مدیریت Blacklist / Whitelist", 0xFF252D3D);
        manageApps.setOnClickListener(v -> showAppManager());
        appsCard.addView(manageApps, paramsTop(0, 10));
        Button cleanRam = button("پاک‌سازی برنامه‌های پس‌زمینه", 0xFF24483D);
        cleanRam.setOnClickListener(v -> cleanBackgroundApps());
        appsCard.addView(cleanRam, paramsTop(0, 8));
        appsCard.addView(text("محدودیت اندروید: برنامه عادی نمی‌تواند اجرای مجدد برنامه‌های دیگر را به‌طور دائمی مسدود کند. این ابزار فقط می‌تواند درخواست توقف اجباری برای برنامه‌های انتخاب‌شده بفرستد.", 12, 0xFFFFC857, false), paramsTop(0, 10));

        TextView panelTitle = text("پنل شناور Gaming و FPS واقعی", 18, Color.WHITE, true);
        panelTitle.setPadding(0, dp(26), 0, dp(12));
        root.addView(panelTitle);
        LinearLayout panelCard = card(); panelCard.setPadding(dp(16),dp(14),dp(16),dp(14)); root.addView(panelCard);
        panelCard.addView(text("پنل روی بازی شناور می‌ماند؛ از آن می‌توان FPS عددی/نموداری و دکمه لمسی مجازی را کنترل کرد.",13,0xFFB9C1D1,false));
        Button startPanel = button("نمایش / شروع پنل شناور Gaming",0xFF24483D);
        startPanel.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) { startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); toast("اجازه نمایش روی برنامه‌های دیگر را فعال کن."); return; }
            startService(new Intent(this,FloatingGamingService.class)); toast("پنل شناور اجرا شد.");
        }); panelCard.addView(startPanel,paramsTop(0,10));
        Button touchSetup = button("تنظیم مقصد و ظاهر دکمه مجازی",0xFF252D3D);
        touchSetup.setOnClickListener(v -> configureTouchMapping()); panelCard.addView(touchSetup,paramsTop(0,8));
        Button accessibility = button("فعال‌سازی مجوز Touch Mapping",0xFF252D3D);
        accessibility.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("هشدار Touch Mapping")
            .setMessage("این قابلیت با سرویس دسترس‌پذیری، یک لمس را در مختصاتی که خودت تعیین می‌کنی شبیه‌سازی می‌کند. استفاده از ورودی مجازی در COD Mobile ممکن است با قوانین بازی تعارض داشته باشد و خطر محدودیت یا بن حساب را دارد. هیچ تضمینی برای بی‌خطر بودن آن وجود ندارد. برای فعال‌سازی، سرویس RRM را در تنظیمات دسترس‌پذیری روشن کن.")
            .setNegativeButton("لغو",null).setPositiveButton("رفتن به تنظیمات",(d,w)->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))).show());
        panelCard.addView(accessibility,paramsTop(0,8));
        panelCard.addView(text("FPS از شمارنده فریم dumpsys gfxinfo برنامه انتخاب‌شده در بازه تقریباً یک‌ثانیه‌ای خوانده می‌شود؛ در بعضی بازی‌ها/درایورها ممکن است عدد در دسترس نباشد یا صفر نمایش داده شود.",12,0xFFFFC857,false),paramsTop(0,10));

        logText = text("اتصال این نسخه از طریق Wireless Debugging و موتور ADB داخلی انجام می‌شود. برای Pairing، پورت و کد را از صفحه Wireless debugging وارد کن.", 12, 0xFF737E91, false);
        logText.setPadding(dp(2), dp(20), dp(2), 0);
        root.addView(logText);
        setContentView(scroll);
    }

    private View profile(String name, String size, String dpi, String command) {
        LinearLayout box = card();
        box.setPadding(dp(16), dp(14), dp(16), dp(14));
        TextView label = text(name, 11, 0xFF9A8BFF, true);
        box.addView(label);
        TextView dimensions = text(size, 25, Color.WHITE, true);
        dimensions.setPadding(0, dp(5), 0, 0);
        box.addView(dimensions);
        TextView density = text(dpi, 13, 0xFF9AA3B5, false);
        density.setPadding(0, dp(2), 0, dp(10));
        box.addView(density);
        Button apply = button("اعمال این پروفایل", 0xFF30285A);
        apply.setOnClickListener(v -> runShell(command, "پروفایل " + size + " اعمال شد"));
        box.addView(apply, matchWrap());
        return box;
    }

    private SharedPreferences overlayPrefs() { return getSharedPreferences("overlay", MODE_PRIVATE); }
    private void saveOverlay(String key, Object value) {
        SharedPreferences.Editor e = overlayPrefs().edit();
        if (value instanceof Integer) e.putInt(key, (Integer)value); else e.putString(key, String.valueOf(value));
        e.apply();
    }
    private void toggleCrosshair() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            toast("اجازه نمایش روی برنامه‌های دیگر را فعال کن و برگرد.");
            return;
        }
        Intent i = new Intent(this, CrosshairService.class);
        if (overlayPrefs().getBoolean("enabled", false)) {
            stopService(i); overlayPrefs().edit().putBoolean("enabled", false).apply(); toast("نشانگر خاموش شد");
        } else {
            overlayPrefs().edit().putBoolean("enabled", true).apply();
            startService(i);
            toast("نشانگر روشن شد");
        }
    }
    private void updateOverlayIfRunning() {
        if (overlayPrefs().getBoolean("enabled", false)) {
            Intent i = new Intent(this, CrosshairService.class); i.setAction("UPDATE");
            startService(i);
        }
    }
    private void chooseCrosshairShape() {
        String[] shapes = {"•", "●", "+", "-", "°", "×", "#", "(", ")", "^"};
        new AlertDialog.Builder(this).setTitle("شکل نشانگر").setItems(shapes, (d, which) -> { saveOverlay("shape", shapes[which]); updateOverlayIfRunning(); }).show();
    }
    private void chooseCrosshairColor() {
        String[] names = {"سبز", "سفید", "قرمز", "آبی", "سیاه"};
        int[] colors = {Color.GREEN, Color.WHITE, Color.RED, Color.BLUE, Color.BLACK};
        new AlertDialog.Builder(this).setTitle("رنگ نشانگر").setItems(names, (d, which) -> { saveOverlay("color", colors[which]); updateOverlayIfRunning(); }).show();
    }

    private boolean isCallOfDuty(String pkg) {
        return COD_PACKAGE.equals(pkg) || COD_GARENA_PACKAGE.equals(pkg) || pkg.toLowerCase().contains("callofduty");
    }

    private Set<String> getSet(String key) {
        return new HashSet<>(getSharedPreferences("app_lists", MODE_PRIVATE).getStringSet(key, Collections.emptySet()));
    }

    private void saveSet(String key, Set<String> values) {
        getSharedPreferences("app_lists", MODE_PRIVATE).edit().putStringSet(key, new HashSet<>(values)).apply();
    }

    private List<ApplicationInfo> getLaunchableApps() {
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> apps = new ArrayList<>();
        for (ApplicationInfo info : pm.getInstalledApplications(PackageManager.GET_META_DATA)) {
            if (info.packageName.equals(getPackageName()) || isCallOfDuty(info.packageName)) continue;
            if ((info.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
            if (pm.getLaunchIntentForPackage(info.packageName) != null) apps.add(info);
        }
        Collections.sort(apps, (a, b) -> pm.getApplicationLabel(a).toString().compareToIgnoreCase(pm.getApplicationLabel(b).toString()));
        return apps;
    }

    private void showAppManager() {
        List<ApplicationInfo> apps = getLaunchableApps();
        String[] labels = new String[apps.size()];
        for (int i = 0; i < apps.size(); i++) labels[i] = getPackageManager().getApplicationLabel(apps.get(i)) + "  ·  " + apps.get(i).packageName;
        boolean[] selected = new boolean[apps.size()];
        AlertDialog picker = new AlertDialog.Builder(this).setTitle("انتخاب برنامه‌ها")
            .setMultiChoiceItems(labels, selected, (dialog, which, checked) -> selected[which] = checked)
            .setPositiveButton("انتقال انتخاب‌ها", null)
            .setNeutralButton("انتخاب همه", null)
            .setNegativeButton("مدیریت فهرست‌ها", null).create();
        picker.setOnShowListener(ignored -> {
            picker.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                boolean all = true;
                for (boolean value : selected) if (!value) { all = false; break; }
                for (int i = 0; i < selected.length; i++) {
                    selected[i] = !all;
                    picker.getListView().setItemChecked(i, !all);
                }
                picker.getButton(AlertDialog.BUTTON_NEUTRAL).setText(all ? "انتخاب همه" : "لغو انتخاب همه");
            });
            picker.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                boolean any = false; for (boolean value : selected) if (value) any = true;
                if (!any) { toast("حداقل یک برنامه را انتخاب کن."); return; }
                new AlertDialog.Builder(this).setTitle("نوع فهرست مقصد")
                    .setItems(new String[]{"افزودن به Blacklist", "افزودن به Whitelist"}, (d, choice) -> {
                        String key = choice == 0 ? "black" : "white";
                        String other = choice == 0 ? "white" : "black";
                        Set<String> target = getSet(key), opposite = getSet(other);
                        for (int i = 0; i < apps.size(); i++) if (selected[i]) { target.add(apps.get(i).packageName); opposite.remove(apps.get(i).packageName); }
                        saveSet(key, target); saveSet(other, opposite);
                        toast("فهرست به‌روزرسانی شد. Blacklist: " + getSet("black").size() + " / Whitelist: " + getSet("white").size());
                    }).show();
                picker.dismiss();
            });
            picker.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> {
                new AlertDialog.Builder(this).setTitle("مدیریت فهرست‌ها")
                    .setItems(new String[]{"مشاهده / حذف Blacklist", "مشاهده / حذف Whitelist", "پاک‌کردن هر دو فهرست"}, (d, choice) -> {
                        if (choice == 2) {
                            new AlertDialog.Builder(this).setMessage("هر دو فهرست خالی شوند؟")
                                .setNegativeButton("لغو", null).setPositiveButton("پاک‌کردن", (x, y) -> {
                                    saveSet("black", new HashSet<>()); saveSet("white", new HashSet<>()); toast("هر دو فهرست پاک شدند.");
                                }).show();
                            return;
                        }
                        String key = choice == 0 ? "black" : "white";
                        Set<String> entries = getSet(key);
                        if (entries.isEmpty()) { toast("این فهرست خالی است."); return; }
                        List<String> values = new ArrayList<>(entries);
                        String[] names = values.toArray(new String[0]);
                        new AlertDialog.Builder(this).setTitle("برای حذف انتخاب کن")
                            .setMultiChoiceItems(names, null, (x, index, checked) -> { })
                            .setPositiveButton("حذف موارد انتخاب‌شده", (x, y) -> {
                                AlertDialog a = (AlertDialog)x;
                                Set<String> updated = getSet(key);
                                for (int i = 0; i < names.length; i++) if (a.getListView().isItemChecked(i)) updated.remove(names[i]);
                                saveSet(key, updated); toast("فهرست به‌روزرسانی شد.");
                            }).setNegativeButton("بستن", null).show();
                    }).show();
                picker.dismiss();
            });
        });
        picker.show();
    }

    private void cleanBackgroundApps() {
        Set<String> white = getSet("white");
        Set<String> black = getSet("black");
        List<ApplicationInfo> apps = getLaunchableApps();
        StringBuilder command = new StringBuilder();
        int count = 0;
        for (ApplicationInfo app : apps) {
            String pkg = app.packageName;
            if (isCallOfDuty(pkg) || pkg.equals(getPackageName()) || white.contains(pkg)) continue;
            // The cleaner only force-stops launchable user apps; Android/system components are not enumerated.
            if (black.isEmpty() || black.contains(pkg)) {
                if (command.length() > 0) command.append("; ");
                command.append("am force-stop ").append(pkg);
                count++;
            }
        }
        if (count == 0) { toast("برنامه‌ای برای پاک‌سازی انتخاب نشده است."); return; }
        new AlertDialog.Builder(this).setTitle("تأیید پاک‌سازی")
            .setMessage("برای " + count + " برنامه درخواست توقف اجباری ارسال شود؟\nCOD Mobile و برنامه‌های Whitelist مستثنا هستند.")
            .setNegativeButton("لغو", null).setPositiveButton("پاک‌سازی", (d, w) -> runShell(command.toString(), "درخواست توقف برای " + count + " برنامه ارسال شد.")).show();
    }

    private void configureTouchMapping() {
        SharedPreferences p=getSharedPreferences("gaming",MODE_PRIVATE);
        LinearLayout form=new LinearLayout(this); form.setPadding(dp(18),dp(8),dp(18),dp(8)); form.setOrientation(LinearLayout.VERTICAL);
        android.widget.EditText x=new android.widget.EditText(this); x.setInputType(2); x.setSingleLine(true); x.setHint("مقصد افقی X از ۰ تا ۱۰۰ درصد"); x.setText(String.valueOf(p.getInt("target_x",50))); form.addView(x);
        android.widget.EditText y=new android.widget.EditText(this); y.setInputType(2); y.setSingleLine(true); y.setHint("مقصد عمودی Y از ۰ تا ۱۰۰ درصد"); y.setText(String.valueOf(p.getInt("target_y",50))); form.addView(y);
        android.widget.EditText size=new android.widget.EditText(this); size.setInputType(2); size.setSingleLine(true); size.setHint("اندازه دکمه ۴۰ تا ۱۴۰ درصد"); size.setText(String.valueOf(p.getInt("touch_size",100))); form.addView(size);
        android.widget.EditText opacity=new android.widget.EditText(this); opacity.setInputType(2); opacity.setSingleLine(true); opacity.setHint("شفافیت ۰ تا ۱۰۰ درصد"); opacity.setText(String.valueOf(p.getInt("touch_opacity",75))); form.addView(opacity);
        new AlertDialog.Builder(this).setTitle("تنظیم دکمه لمسی مجازی")
            .setMessage("مقصد لمس بر اساس درصد ابعاد صفحه است. خود دکمه پس از نمایش پنل قابل کشیدن به هر نقطه‌ای است.")
            .setView(form).setNegativeButton("لغو",null).setPositiveButton("ذخیره",(d,w)->{
                try {
                    int xv=Integer.parseInt(x.getText().toString()),yv=Integer.parseInt(y.getText().toString());
                    int sv=Integer.parseInt(size.getText().toString()),ov=Integer.parseInt(opacity.getText().toString());
                    if(xv<0||xv>100||yv<0||yv>100||sv<40||sv>140||ov<0||ov>100) throw new IllegalArgumentException();
                    p.edit().putInt("target_x",xv).putInt("target_y",yv).putInt("touch_size",sv).putInt("touch_opacity",ov).apply();
                    String[] shapes={"TAP","●","■","+"};
                    new AlertDialog.Builder(this).setTitle("شکل دکمه مجازی").setSingleChoiceItems(shapes,0,(sd,which)->{p.edit().putString("touch_shape",shapes[which]).apply();sd.dismiss();}).setNegativeButton("بعداً",null).show();
                    String[] colors={"سبز","سفید","قرمز","آبی"}; int[] colorValues={0xFF2B8A70,Color.WHITE,Color.RED,Color.BLUE};
                    new AlertDialog.Builder(this).setTitle("رنگ دکمه مجازی").setItems(colors,(cd,which)->p.edit().putInt("touch_color",colorValues[which]).apply()).show();
                    toast("تنظیمات ذخیره شد؛ پنل را یک‌بار ببند و دوباره باز کن.");
                } catch(Exception e){toast("مقادیر واردشده معتبر نیستند.");}
            }).show();
    }

    private void connectOrRequest() {
        final android.widget.EditText host = new android.widget.EditText(this);
        host.setSingleLine(true); host.setHint("IP گوشی (معمولاً 127.0.0.1)"); host.setText("127.0.0.1");
        final android.widget.EditText pairPort = new android.widget.EditText(this);
        pairPort.setSingleLine(true); pairPort.setInputType(2); pairPort.setHint("Pairing port");
        final android.widget.EditText code = new android.widget.EditText(this);
        code.setSingleLine(true); code.setInputType(2); code.setHint("کد ۶ رقمی Pairing");
        final android.widget.EditText connectPort = new android.widget.EditText(this);
        connectPort.setSingleLine(true); connectPort.setInputType(2); connectPort.setHint("Wireless debugging port");
        LinearLayout form = new LinearLayout(this); form.setPadding(dp(20),dp(8),dp(20),dp(8)); form.setOrientation(LinearLayout.VERTICAL);
        form.addView(host); form.addView(pairPort); form.addView(code); form.addView(connectPort);
        new AlertDialog.Builder(this).setTitle("اتصال داخلی ADB")
            .setMessage("در تنظیمات توسعه‌دهنده، Wireless debugging را روشن کن. در صفحه Pair device with pairing code، پورت و کد را وارد کن. سپس پورت اصلی Wireless debugging را هم وارد کن.")
            .setView(form).setNegativeButton("لغو",null)
            .setPositiveButton("Pair و اتصال",(d,w)-> {
                String h=host.getText().toString().trim();
                try {
                    int pp=Integer.parseInt(pairPort.getText().toString().trim());
                    int cp=Integer.parseInt(connectPort.getText().toString().trim());
                    String pin=code.getText().toString().trim();
                    getSharedPreferences("adb",MODE_PRIVATE).edit().putString("host",h).putInt("port",cp).apply();
                    setStatus("در حال جفت‌سازی و اتصال...",false);
                    ADBBridge.pairAndConnect(this,h,pp,pin,cp, result -> runOnUiThread(() -> {
                        setStatus(result,true); refreshCurrent();
                    }), error -> runOnUiThread(() -> setStatus("اتصال ناموفق: "+error,false)));
                } catch(Exception ex) { toast("پورت‌ها را به‌صورت عددی وارد کن."); }
            }).show();
    }

    private void updateConnectionState() {
        String h=getSharedPreferences("adb",MODE_PRIVATE).getString("host",null);
        int p=getSharedPreferences("adb",MODE_PRIVATE).getInt("port",0);
        setStatus(h==null ? "ADB هنوز جفت‌سازی نشده" : "اطلاعات اتصال ذخیره شده؛ برای اتصال دوباره بزن",false);
    }

    private void refreshCurrent() { runShell("wm size; wm density", null); }

    private void runShell(String command, String successMessage) {
        String h=getSharedPreferences("adb",MODE_PRIVATE).getString("host",null);
        int p=getSharedPreferences("adb",MODE_PRIVATE).getInt("port",0);
        if(h==null || p==0) { toast("ابتدا ADB را Pair و متصل کن."); connectOrRequest(); return; }
        setStatus("در حال اجرای فرمان...",false);
        ADBBridge.shell(h,p,command, output -> runOnUiThread(() -> {
            setStatus("فرمان اجرا شد",true);
            if(currentText!=null) currentText.setText(output);
            if(successMessage!=null) toast(successMessage);
        }), error -> runOnUiThread(() -> { setStatus("اجرای فرمان ناموفق بود",false); toast(error); }));
    }

    private void setStatus(String message, boolean ok) {
        if (statusText != null) {
            statusText.setText((ok ? "●  " : "○  ") + message);
            statusText.setTextColor(ok ? 0xFF71E0B1 : 0xFFFFC857);
        }
    }

    private LinearLayout card() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF141925);
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), 0xFF252D3D);
        layout.setBackground(bg);
        return layout;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String label, int color) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(13);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(12));
        b.setBackground(bg);
        b.setPadding(dp(10), dp(5), dp(10), dp(5));
        return b;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }
    private LinearLayout.LayoutParams paramsTop(int width, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(width == 0 ? -1 : width, -2);
        p.topMargin = dp(top);
        return p;
    }
    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }

    @Override protected void onDestroy() {
        super.onDestroy();
        worker.shutdown();
    }
}
