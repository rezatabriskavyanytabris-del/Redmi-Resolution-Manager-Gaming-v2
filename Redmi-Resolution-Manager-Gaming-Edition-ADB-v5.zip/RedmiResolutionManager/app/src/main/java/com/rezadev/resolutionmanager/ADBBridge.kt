package com.rezadev.resolutionmanager

import android.content.Context
import com.flyfishxu.kadb.Kadb
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

/** Internal Wireless Debugging ADB bridge. No Shizuku dependency is used. */
object ADBBridge {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @JvmStatic
    fun pairAndConnect(
        context: Context,
        host: String,
        pairingPort: Int,
        pairingCode: String,
        connectPort: Int,
        success: (String) -> Unit,
        failure: (String) -> Unit
    ) {
        scope.launch {
            try {
                Kadb.pair(host, pairingPort, pairingCode)
                Kadb.create(host, connectPort).use { adb ->
                    val result = adb.shell("echo RRM_ADB_CONNECTED")
                    if (result.exitCode != 0 || !result.output.contains("RRM_ADB_CONNECTED")) {
                        throw IllegalStateException(result.output.ifBlank { "ADB connection verification failed" })
                    }
                }
                context.getSharedPreferences("adb", Context.MODE_PRIVATE).edit()
                    .putString("host", host).putInt("port", connectPort).apply()
                success("ADB داخلی متصل شد")
            } catch (t: Throwable) {
                failure(t.message ?: t.javaClass.simpleName)
            }
        }
    }

    @JvmStatic
    fun shell(host: String, port: Int, command: String, success: (String) -> Unit, failure: (String) -> Unit) {
        scope.launch {
            try {
                Kadb.create(host, port).use { adb ->
                    val result = adb.shell(command)
                    if (result.exitCode != 0) throw IllegalStateException(result.output.ifBlank { "Command failed" })
                    success(result.output)
                }
            } catch (t: Throwable) {
                failure(t.message ?: t.javaClass.simpleName)
            }
        }
    }
}
