package com.rezadev.resolutionmanager;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;

public class CrosshairService extends Service {
    private WindowManager wm;
    private TextView marker;
    private WindowManager.LayoutParams params;
    @Override public void onCreate() { super.onCreate(); wm=(WindowManager)getSystemService(WINDOW_SERVICE); }
    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        if (intent != null && "UPDATE".equals(intent.getAction())) { updateMarker(); return START_STICKY; }
        if (marker == null) showMarker(); else updateMarker();
        return START_STICKY;
    }
    private void showMarker() {
        if (!android.provider.Settings.canDrawOverlays(this)) { stopSelf(); return; }
        marker = new TextView(this); marker.setGravity(Gravity.CENTER); marker.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        marker.setText(getSharedPreferences("overlay",MODE_PRIVATE).getString("shape","•"));
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.CENTER;
        try { wm.addView(marker,params); updateMarker(); } catch(Exception e) { stopSelf(); }
    }
    private void updateMarker() {
        if(marker==null) { showMarker(); return; }
        android.content.SharedPreferences p=getSharedPreferences("overlay",MODE_PRIVATE);
        marker.setText(p.getString("shape","•")); marker.setTextColor(p.getInt("color",Color.GREEN));
        marker.setAlpha(Math.max(0f,Math.min(1f,p.getInt("opacity",100)/100f)));
        float scale=p.getInt("size",100)/100f;
        marker.setTextSize(32f*scale);
        marker.setShadowLayer(2f*scale,0,0,Color.BLACK);
    }
    @Override public void onDestroy(){ if(marker!=null){try{wm.removeView(marker);}catch(Exception ignored){} marker=null;} super.onDestroy(); }
    @Override public IBinder onBind(Intent intent){return null;}
}
