package com.rezadev.resolutionmanager;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.view.View;
import java.util.List;

/** Lightweight line graph for the last 30 one-second FPS samples. */
public class FpsGraphView extends View {
    private final Paint line=new Paint(3), grid=new Paint(1), text=new Paint(1);
    private int[] values=new int[0];
    public FpsGraphView(Context c){super(c);line.setColor(0xFF70E0B5);line.setStrokeWidth(3);line.setStyle(Paint.Style.STROKE);grid.setColor(0x557F8AA3);grid.setStrokeWidth(1);text.setColor(Color.WHITE);text.setTextSize(11);}
    public void setValues(List<Integer> data){values=new int[data.size()];for(int i=0;i<data.size();i++)values[i]=data.get(i);postInvalidate();}
    @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();c.drawColor(0xEE20283A);for(int i=1;i<4;i++)c.drawLine(6,h*i/4,w-6,h*i/4,grid);c.drawText("FPS",8,14,text);if(values.length<2)return;float max=60;for(int v:values)max=Math.max(max,v);float dx=(w-16f)/(values.length-1);for(int i=1;i<values.length;i++){float x1=8+(i-1)*dx,x2=8+i*dx;float y1=h-8-(values[i-1]/max)*(h-24),y2=h-8-(values[i]/max)*(h-24);c.drawLine(x1,y1,x2,y2,line);}c.drawText(String.valueOf(values[values.length-1]),w-32,14,text);}
}
