package com.rezadev.resolutionmanager;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

/** Sends a single tap at a user-configured screen percentage after explicit accessibility opt-in. */
public class TouchAccessibilityService extends AccessibilityService {
    public static volatile TouchAccessibilityService instance;
    @Override protected void onServiceConnected(){super.onServiceConnected();instance=this;}
    @Override public void onAccessibilityEvent(AccessibilityEvent event){}
    @Override public void onInterrupt(){}
    @Override public void onDestroy(){if(instance==this)instance=null;super.onDestroy();}
    public void tapPercent(int xPercent,int yPercent){
        if(Build.VERSION.SDK_INT<24)return;
        DisplayMetrics dm=new DisplayMetrics(); ((WindowManager)getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
        float x=dm.widthPixels*Math.max(0,Math.min(100,xPercent))/100f;
        float y=dm.heightPixels*Math.max(0,Math.min(100,yPercent))/100f;
        Path path=new Path();path.moveTo(x,y);
        GestureDescription.StrokeDescription stroke=new GestureDescription.StrokeDescription(path,0,65);
        dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(),null,null);
    }
}
